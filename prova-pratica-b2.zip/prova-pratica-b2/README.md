# Conteúdo do Trabalho

Tela de login

Tela Registro

Tela Esqueci minha senha

Tela Principal

Tela dos grupos do inova com nome, descrição, integrantes e tema


info.map(ele => <text>[ele.nome]</text>)