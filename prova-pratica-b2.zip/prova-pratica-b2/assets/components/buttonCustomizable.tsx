import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

const CustomizableButton = ({ onPress, title, color }) => (
    <TouchableOpacity
        style={[styles.button, { backgroundColor: color }]}
        onPress={onPress}
    >
        <Text>{title}</Text>
    </TouchableOpacity>
);

const styles = StyleSheet.create({
    button: {
        borderRadius: 10,
        overflow: 'hidden',
        padding: 10,
        // outros estilos que você desejar
    },
});