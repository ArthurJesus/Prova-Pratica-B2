const grupos = [
  {
    nome:'grupo1',
    tema:'tema1',
    descricao:'dcGrupo1',
    integrantes:[
      'fulano',
      'ciclano',
      'beltrano'
    ]
  }
]