import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { supabase } from '../lib/supabase'; // Importando o client do Supabase

const RegisterPage = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleRegister = async () => {

    if (password !== confirmPassword) {
      alert('As senhas não coincidem!');
      return;
    }


    if (!username || username.length < 3) {
      alert('Por favor, insira um nome de usuário válido (pelo menos 3 caracteres)');
      return;
    }

    setIsLoading(true); 

    try {

      const { data: { user }, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        alert(error.message); 
        setIsLoading(false);
        return;
      }

      const { error: profileError } = await supabase
        .from('profiles')
        .insert([
          {
            id: user.id,
            username: username,
          }
        ]);

      if (profileError) {
        console.error('Erro ao inserir o perfil:', profileError.message);
        alert('Erro ao criar perfil');
        setIsLoading(false);
        return;
      }

      alert('Conta criada com sucesso!');
      setIsLoading(false);
      navigation.navigate('Login');
    } catch (error) {
      console.error('Erro no registro', error);
      alert('Erro ao criar conta');
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Registrar-se</Text>

      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <TextInput
        style={styles.input}
        placeholder="Senha"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      <TextInput
        style={styles.input}
        placeholder="Confirmar Senha"
        value={confirmPassword}
        onChangeText={setConfirmPassword}
        secureTextEntry
      />

      <TextInput
        style={styles.input}
        placeholder="Nome de Usuário"
        value={username}
        onChangeText={setUsername}
      />

      <Button title={isLoading ? "Registrando..." : "Criar Conta"} onPress={handleRegister} disabled={isLoading} />

      <Text style={styles.switchText}>
        Já tem uma conta?{' '}
        <Text
          style={styles.link}
          onPress={() => navigation.navigate('Login')}
        >
          Faça login
        </Text>
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 40,
  },
  input: {
    height: 50,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 20,
    paddingHorizontal: 10,
    borderRadius: 8,
  },
  switchText: {
    textAlign: 'center',
    marginTop: 20,
  },
  link: {
    color: '#007BFF',
  },
});

export default RegisterPage;
